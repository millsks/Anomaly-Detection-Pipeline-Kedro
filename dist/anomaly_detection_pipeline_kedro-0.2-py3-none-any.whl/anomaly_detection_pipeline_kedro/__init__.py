"""Anomaly Detection Pipeline (Kedro)
"""

__version__ = "0.1"
