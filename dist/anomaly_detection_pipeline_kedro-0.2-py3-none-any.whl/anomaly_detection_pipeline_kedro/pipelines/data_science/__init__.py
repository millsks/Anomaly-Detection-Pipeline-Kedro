"""
This is a boilerplate pipeline 'data_science'
generated using Kedro 0.17.7
"""

from .pipeline import create_pipeline

__all__ = ["create_pipeline"]
