"""
This is a boilerplate pipeline 'model_evaluation'
generated using Kedro 0.17.7
"""

from .pipeline import create_pipeline

__all__ = ["create_pipeline"]
